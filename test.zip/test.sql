
-- ## THIS SCRIPT LOOPS THROUGH ALL FILES IN \datasets\ DIRECTORY AND PRODUCES OUTPUT FOR EACH FILE PER LINE IN FORMAT REQUESTED
-- ## DEPENDING ON PERMISSIONS, THE FILE LIST CAN BE OBTAINED VIA CMDSHELL, BUT MOST USERS WOULD NOT BE ABLE TO ACCESS THAT COMMAND, SO AN EXECUTABLE .bat FILE IS PROVIDED INSTEAD

-- # DECLARE MAIN PATH VARIABLES - THESE CAN BE INPUT BY USER IF STORED PROCEDURE / WEB APP

declare @path_main varchar(max) = 'c:\test\'
declare @path_datasets varchar(max) = @path_main + '\datasets\'
declare @terminator varchar(20) = ','

declare @dirpath varchar(max) = @path_main + 'dir.csv'
declare @sql_insertfiles varchar(max)

-- # RECREATE OUTPUT TABLE (COMMENT OUT IF EXISTING OUTPUT TABLE IS TO BE RETAINED BETWEEN SESSIONS)

IF OBJECT_ID('dbo.OutputTable', 'U') IS NOT NULL DROP TABLE dbo.OutputTable; 

CREATE TABLE dbo.OutputTable(
filename varchar(max),
buyDayofMonth varchar(50),
sellDayofMonth varchar(50)
)

-- # PREPARE FILE NAME TABLE
-- # execute runthisfirst.bat first to create dir.csv file in target directory (could be executed via cmdshell if permissions allow)

IF OBJECT_ID('tempdb.dbo.#FileTable_staging', 'U') IS NOT NULL DROP TABLE #FileTable_staging; 

CREATE TABLE #FileTable_staging(
filename varchar(max)
)

set @sql_insertfiles = 'BULK INSERT #FileTable_staging
FROM ''' + @dirpath + '''
WITH 
  ( FIELDTERMINATOR = ''/n'' 
  )
  '

-- print @sql_insertfiles
-- print @fullpath

exec(@sql_insertfiles)

IF OBJECT_ID('dbo.FileTable', 'U') IS NOT NULL DROP TABLE dbo.FileTable; 

select row_number() over (order by filename) as rowid, * into dbo.filetable from #filetable_staging

-- # LOOP THROUGH FILES IN FILE TABLE

	-- # DECLARE VARIABLES FOR FILE LIST

declare @fileid_min varchar(5)
declare @fileid_max varchar(5)
select @fileid_min = min(rowid) from dbo.filetable
select @fileid_max = max(rowid) from dbo.filetable

while @fileid_min <= @fileid_max

begin
 
		-- # DECLARE VARIABLES FOR EACH FILE IN FILE LIST

declare @filename varchar(max)
select @filename = filename from dbo.filetable where rowid = @fileid_min

declare @fullpath varchar(max) = @path_datasets + @filename

declare @sql_bulkinsert_file varchar(max)
declare @sql_result varchar(max)

IF OBJECT_ID('tempdb.dbo.#StagingTable', 'U') IS NOT NULL DROP TABLE #StagingTable; 

CREATE TABLE #StagingTable(
[Price] [Float]
)

set @sql_bulkinsert_file = 'BULK INSERT #StagingTable
FROM ''' + @fullpath + '''
WITH 
  (
    ROWTERMINATOR = ''' + @terminator + ''' 
  )
  '

-- print @sql_insert
-- print @sql_result

exec(@sql_bulkinsert_file)

IF OBJECT_ID('tempdb.dbo.#prices', 'U') IS NOT NULL DROP TABLE #prices; 

select row_number() over (order by (select NULL)) as dayofmonth, price into #prices from #StagingTable

IF OBJECT_ID('tempdb.dbo.#control', 'U') IS NOT NULL DROP TABLE #control; 

select 1 as a, row_number() over (order by price) as priceorder, *, 0 as pricediff into #control from #prices order by Price

IF OBJECT_ID('tempdb.dbo.#output', 'U') IS NOT NULL DROP TABLE #output; 

create table #output (
dayofmonth1 int,
price1 float,
dayofmonth2 int,
price2 float,
pricediff float
)

-- # loop through prices in each file

declare @po_min varchar(3)
declare @po_max varchar(3)

select @po_min = min( priceorder ) from #control

print @po_min

while @po_min is not null -- loop #1, sort by minimum price
	
	begin

		select @po_max = max( priceorder ) from #control

			while @po_max is not null -- loop #2, sort by maximum price
				
				begin
   
					IF OBJECT_ID('tempdb.dbo.#sort1', 'U') IS NOT NULL DROP TABLE #sort1; 

					select a.dayofmonth as dayofmonth1, a.price as price1, b.dayofmonth as dayofmonth2, b.price as price2, b.Price - a.Price as Pricediff, b.dayofmonth - a.dayofmonth as Daydiff  into #sort1
					from #control a left join (select 1 as b, * from #control where priceorder = @po_max) b on a.a = b.b 
					where a.priceorder = @po_min 
	
						insert into #output 
						select dayofmonth1, price1, dayofmonth2, price2, pricediff from #sort1 where daydiff > 0 and pricediff > 0 -- select only where increase in price and date
 
					select @po_max = max( priceorder ) from #control where priceorder < @po_max
	
				end
 
			select @po_min = min( priceorder ) from #control where priceorder > @po_min

	end

IF OBJECT_ID('dbo.result', 'U') IS NOT NULL DROP TABLE dbo.result; 

 
declare @staging_result varchar(max)

set @staging_result = 'select top 1 ''' + @filename + ''' as filename, cast(dayofmonth1 as varchar(10)) +  ''('' + cast(price1 as varchar(10)) + '')'' as buyDayofMonth, 
cast(dayofmonth2 as varchar(10)) + ''('' + cast(price2 as varchar(10)) +'')'' as sellDayofMonth
into dbo.result from #output order by pricediff desc' -- select largest increase in price

-- print @staging_result

exec (@staging_result)

set @sql_result = 'insert into dbo.OutputTable select a.* from dbo.result a left join dbo.OutputTable b on a.filename = b.filename where b.filename is null' -- only adds new results to outputtable

-- set @sql_result = 'insert into dbo.OutputTable select a.* from dbo.result a' -- alternative version adds all results to outputtable, including duplicates
 
-- print @sql_result

exec(@sql_result)

set @fileid_min = @fileid_min + 1

end

drop table dbo.result -- clean up

select * from dbo.OutputTable -- final result
 
